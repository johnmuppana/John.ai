Install all the necessary packages by running the below code in project folder terminal 

npm install express ejs mongoose dotenv marked body-parser express-session @google/generative-ai


NOTE: make sure to paste your google gemini-flash API key in server.js before starting the server.